from setuptools import setup, find_packages

setup(
   name='requests',
   version='X',
   author='Blank-c',
   packages=find_packages(),
   url='https://github.com/Blank-c/Blank-Grabber',
   description='The mock module',
   long_description="Hello I am a module",
   long_description_content_type='text/markdown',
   install_requires=[],
   keywords='requests'
)